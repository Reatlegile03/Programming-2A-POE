﻿using RecipeApp_WPF.Models;
using System;
using System.Windows;
using Microsoft.VisualBasic;

namespace RecipeApp_WPF
{
    public partial class AddRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public AddRecipeWindow()
        {
            InitializeComponent();
            Recipe = new Recipe();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string name = Interaction.InputBox("Enter the ingredient name:", "Add Ingredient", "");
            string quantityInput = Interaction.InputBox("Enter the quantity:", "Add Ingredient", "");
            string originalQuantityInput = quantityInput; // Assuming original quantity is the same as the entered quantity
            string unit = Interaction.InputBox("Enter the unit of measure:", "Add Ingredient", "");
            string caloriesInput = Interaction.InputBox("Enter the calories per unit:", "Add Ingredient", "");
            string foodGroup = Interaction.InputBox("Enter the food group:", "Add Ingredient", "");

            if (double.TryParse(quantityInput, out double quantity) &&
                double.TryParse(originalQuantityInput, out double originalQuantity) &&
                double.TryParse(caloriesInput, out double calories))
            {
                var ingredient = new Ingredient(name, quantity, originalQuantity, unit, calories, foodGroup);
                Recipe.AddIngredient(ingredient);
                IngredientsListBox.Items.Add($"{quantity} {unit} of {name} ({foodGroup}, {calories} cal)");
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid numbers for quantity and calories.");
            }
        }

        private void RemoveIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (IngredientsListBox.SelectedIndex >= 0)
            {
                Recipe.Ingredients.RemoveAt(IngredientsListBox.SelectedIndex);
                IngredientsListBox.Items.RemoveAt(IngredientsListBox.SelectedIndex);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Recipe.Name = RecipeNameTextBox.Text.Trim();
            Recipe.Steps = new List<string>(StepsTextBox.Text.Trim().Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None));
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

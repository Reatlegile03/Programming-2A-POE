﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp_WPF.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
        }

        public void ClearData()
        {
            Ingredients.Clear();
            Steps.Clear();
        }

        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories * i.Quantity);
        }
    }
}

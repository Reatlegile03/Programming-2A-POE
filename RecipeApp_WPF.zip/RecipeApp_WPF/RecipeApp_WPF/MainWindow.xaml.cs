﻿using RecipeApp_WPF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Microsoft.VisualBasic;

namespace RecipeApp_WPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var addRecipeWindow = new AddRecipeWindow();
            if (addRecipeWindow.ShowDialog() == true)
            {
                recipes.Add(addRecipeWindow.Recipe);
                RefreshRecipeList();
            }
        }

        private void DisplayAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            RefreshRecipeList();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            var input = Interaction.InputBox("Enter the name of the recipe to display:", "Display Recipe", "");
            var selectedRecipe = recipes.Find(r => r.Name.Equals(input, StringComparison.OrdinalIgnoreCase));
            if (selectedRecipe != null)
            {
                MessageBox.Show(GetRecipeDetails(selectedRecipe), "Recipe Details");
            }
            else
            {
                MessageBox.Show("Recipe not found!");
            }
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            var input = Interaction.InputBox("Enter the name of the recipe to scale:", "Scale Recipe", "");
            var selectedRecipe = recipes.Find(r => r.Name.Equals(input, StringComparison.OrdinalIgnoreCase));
            if (selectedRecipe != null)
            {
                var scaleInput = Interaction.InputBox("Enter scale factor (0.5, 2, or 3):", "Scale Recipe", "");
                if (double.TryParse(scaleInput, out double scaleFactor) && (scaleFactor == 0.5 || scaleFactor == 2 || scaleFactor == 3))
                {
                    selectedRecipe.Scale(scaleFactor);
                    MessageBox.Show("Recipe scaled successfully!");
                    RefreshRecipeList();
                }
                else
                {
                    MessageBox.Show("Invalid scale factor. Please enter 0.5, 2, or 3.");
                }
            }
            else
            {
                MessageBox.Show("Recipe not found!");
            }
        }

        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            var input = Interaction.InputBox("Enter the name of the recipe to reset quantities:", "Reset Quantities", "");
            var selectedRecipe = recipes.Find(r => r.Name.Equals(input, StringComparison.OrdinalIgnoreCase));
            if (selectedRecipe != null)
            {
                selectedRecipe.ResetQuantities();
                MessageBox.Show("Quantities reset successfully!");
                RefreshRecipeList();
            }
            else
            {
                MessageBox.Show("Recipe not found!");
            }
        }

        private void ClearRecipe_Click(object sender, RoutedEventArgs e)
        {
            var input = Interaction.InputBox("Enter the name of the recipe to clear data:", "Clear Recipe", "");
            var selectedRecipe = recipes.Find(r => r.Name.Equals(input, StringComparison.OrdinalIgnoreCase));
            if (selectedRecipe != null)
            {
                selectedRecipe.ClearData();
                recipes.Remove(selectedRecipe);
                MessageBox.Show("Recipe data cleared successfully!");
                RefreshRecipeList();
            }
            else
            {
                MessageBox.Show("Recipe not found!");
            }
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            string ingredientFilter = FilterIngredientTextBox.Text.Trim();
            string foodGroupFilter = FilterFoodGroupTextBox.Text.Trim();
            string maxCaloriesFilter = FilterMaxCaloriesTextBox.Text.Trim();

            double maxCalories;
            bool maxCaloriesValid = double.TryParse(maxCaloriesFilter, out maxCalories);

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrEmpty(ingredientFilter) || r.Ingredients.Any(i => i.Name.Contains(ingredientFilter, StringComparison.OrdinalIgnoreCase))) &&
                (string.IsNullOrEmpty(foodGroupFilter) || r.Ingredients.Any(i => i.FoodGroup.Equals(foodGroupFilter, StringComparison.OrdinalIgnoreCase))) &&
                (!maxCaloriesValid || r.CalculateTotalCalories() <= maxCalories)).ToList();

            RecipeListView.ItemsSource = filteredRecipes.Select(r => new
            {
                r.Name,
                IngredientsSummary = string.Join(", ", r.Ingredients.Select(i => $"{i.Quantity} {i.Unit} of {i.Name}")),
                TotalCalories = r.CalculateTotalCalories()
            }).ToList();
        }

        private void RefreshRecipeList()
        {
            RecipeListView.ItemsSource = recipes.Select(r => new
            {
                r.Name,
                IngredientsSummary = string.Join(", ", r.Ingredients.Select(i => $"{i.Quantity} {i.Unit} of {i.Name}")),
                TotalCalories = r.CalculateTotalCalories()
            }).ToList();
        }

        private string GetRecipeDetails(Recipe recipe)
        {
            return $"Recipe Name: {recipe.Name}\n\nIngredients:\n" +
                   $"{string.Join("\n", recipe.Ingredients.Select(i => $"{i.Quantity} {i.Unit} of {i.Name} ({i.FoodGroup}, {i.Calories} cal)"))}\n\n" +
                   $"Steps:\n{string.Join("\n", recipe.Steps)}\n\n" +
                   $"Total Calories: {recipe.CalculateTotalCalories()}";
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
